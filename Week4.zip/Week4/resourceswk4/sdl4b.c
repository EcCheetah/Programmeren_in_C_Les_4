/*
Copyright (C) 2020
Sander Gieling
Inholland University of Applied Sciences at Alkmaar, the Netherlands

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation, 
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

// Artwork bibliography
// --------------------
// Reticle taken from here:
// https://flyclipart.com/download-png#printable-crosshair-targets-clip-art-clipart-675613.png
// Blorp taken from here:
// https://opengameart.org/content/animated-top-down-survivor-player
// Desert floor tiling taken from here:
// https://www.flickr.com/photos/maleny_steve/8899498324/in/photostream/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h> // for IMG_Init and IMG_LoadTexture
#include <math.h> // for atan() function

#define SCREEN_WIDTH				1800
#define SCREEN_HEIGHT				1000
#define PI					3.14159265358979323846

// Move this much pixels every frame a move is detected:
#define PLAYER_MAX_SPEED			6.0f

// AFTER a movement-key is released, reduce the movement speed for 
// every consecutive frame by (1.0 - this amount):
#define PLAYER_DECELERATION			0.25f

// Make A Define That Will Set The Amount Of Bullets On Screen//
#define BULLET_MAGAZINE				50
#define BULLET_ACCELERATION			20

int moveY = 0;
int moveX = 0;

// A mouse structure holds mousepointer coords & a pointer texture:
typedef struct _mouse_ {
       	int x;
 	int y;
  	SDL_Texture *txtr_reticle;
} mouse;

// Our Own Struct To Make Bullets //
typedef struct _bullet_ {
 	int bullet_casing;
  	double x;
  	double y;

  	SDL_Texture *txtr_bullet;
  
  	double angle;
} bullet;

// all states for blorp //
typedef enum _playerstate_ {
  	IDLE = 0,
  	WALKING = 1,
  	SHOOTING = 2
} playerstate;

// Added: speed in both directions and rotation angle:
typedef struct _player_ {
  	int x;
  	int y;
  	float speed_x;
  	float speed_y;
  	int up;
  	int down;
  	int left;
  	int right;
  	float angle;
  
  	// for the textures of blorp //
  	SDL_Texture *txtr_body;
  	SDL_Texture *txtr_feet;
  	int location_idle_texture; 
  	int location_moving_texture;
  	playerstate state;
} player;

typedef struct _zombie_ {
	int x;
	int y;
	float angle;
	SDL_Texture *txtr_zombie;
	int location_idle_texture;
} zombie;

typedef enum _visible_ {
	NO = 0,
	YES = 1
} visible;

typedef struct _muzzleflash_ {
	int x;
	int y;
	double angle;
	SDL_Texture *txtr_flash;
	visible visible_state; //Show or dont show the muzzleflash
} muzzleflash;

typedef enum _keystate_ {
  	UP = 0,
  	DOWN = 1
} keystate;

void handle_key(SDL_KeyboardEvent *keyevent, keystate updown, player *tha_playa);



// the functions for bullets
void make_bullet_casing(player *tha_playa);
void show_bullet_route();


// the functions for the muzzleflash
void init_muzzleflash(player *tha_playa, muzzleflash *tha_flash);
void draw_muzzleflash(muzzleflash *tha_flash);

// the function to load textures
void load_texture_blorp(player *tha_playa);

// the function to load the zombie
void load_texture_zombie(player *tha_playa, zombie *tha_zombo);

// This function has changed because mouse movement was added:
void process_input(player *tha_playa, mouse *tha_mouse, muzzleflash *tha_flash);
// This function has changed because mouse movement was added:
void update_player(player *tha_playa, mouse *tha_mouse);
void proper_shutdown(void);
SDL_Texture *load_texture(char *filename);

// This function has changed because texture rotation was added,
// which means drawing a texture centered on a coordinate is easier:
void blit(SDL_Texture *txtr, int x, int y, int center);
void blit_angled(SDL_Texture *txtr, int x, int y, float angle);

float get_angle(int x1, int y1, int x2, int y2, SDL_Texture *texture);

SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;


// Make A Struct Array For Bullets //
struct _bullet_ bullets[BULLET_MAGAZINE];
int bullet_current_casing = 0;
      
char *texturesIdle[20] = {
  	"gfx/idlebody/survivor-idle_handgun_0.png", "gfx/idlebody/survivor-idle_handgun_1.png",
  	"gfx/idlebody/survivor-idle_handgun_2.png", "gfx/idlebody/survivor-idle_handgun_3.png",
  	"gfx/idlebody/survivor-idle_handgun_4.png", "gfx/idlebody/survivor-idle_handgun_5.png",
  	"gfx/idlebody/survivor-idle_handgun_6.png", "gfx/idlebody/survivor-idle_handgun_7.png",
  	"gfx/idlebody/survivor-idle_handgun_8.png", "gfx/idlebody/survivor-idle_handgun_9.png",
  	"gfx/idlebody/survivor-idle_handgun_10.png", "gfx/idlebody/survivor-idle_handgun_11.png",
  	"gfx/idlebody/survivor-idle_handgun_12.png", "gfx/idlebody/survivor-idle_handgun_13.png",
  	"gfx/idlebody/survivor-idle_handgun_14.png", "gfx/idlebody/survivor-idle_handgun_15.png",
  	"gfx/idlebody/survivor-idle_handgun_16.png", "gfx/idlebody/survivor-idle_handgun_17.png",
  	"gfx/idlebody/survivor-idle_handgun_18.png", "gfx/idlebody/survivor-idle_handgun_19.png"
};

char *texturesBody[20] = {
  	"gfx/movebody/survivor-move_handgun_0.png", "gfx/movebody/survivor-move_handgun_1.png",
  	"gfx/movebody/survivor-move_handgun_2.png", "gfx/movebody/survivor-move_handgun_3.png",
  	"gfx/movebody/survivor-move_handgun_4.png", "gfx/movebody/survivor-move_handgun_5.png",
  	"gfx/movebody/survivor-move_handgun_6.png", "gfx/movebody/survivor-move_handgun_7.png",
  	"gfx/movebody/survivor-move_handgun_8.png", "gfx/movebody/survivor-move_handgun_9.png",
  	"gfx/movebody/survivor-move_handgun_10.png", "gfx/movebody/survivor-move_handgun_11.png",
  	"gfx/movebody/survivor-move_handgun_12.png", "gfx/movebody/survivor-move_handgun_13.png",
  	"gfx/movebody/survivor-move_handgun_14.png", "gfx/movebody/survivor-move_handgun_15.png",
  	"gfx/movebody/survivor-move_handgun_16.png", "gfx/movebody/survivor-move_handgun_17.png",
  	"gfx/movebody/survivor-move_handgun_18.png", "gfx/movebody/survivor-move_handgun_19.png"
};
    
char *texturesFeet[20] = {
  	"gfx/movefeet/survivor-walk_0.png", "gfx/movefeet/survivor-walk_1.png", 
  	"gfx/movefeet/survivor-walk_2.png", "gfx/movefeet/survivor-walk_3.png", 
  	"gfx/movefeet/survivor-walk_4.png", "gfx/movefeet/survivor-walk_5.png", 
  	"gfx/movefeet/survivor-walk_6.png", "gfx/movefeet/survivor-walk_7.png", 
  	"gfx/movefeet/survivor-walk_8.png", "gfx/movefeet/survivor-walk_9.png", 
  	"gfx/movefeet/survivor-walk_10.png", "gfx/movefeet/survivor-walk_11.png", 
  	"gfx/movefeet/survivor-walk_12.png", "gfx/movefeet/survivor-walk_13.png", 
  	"gfx/movefeet/survivor-walk_14.png", "gfx/movefeet/survivor-walk_15.png", 
  	"gfx/movefeet/survivor-walk_16.png", "gfx/movefeet/survivor-walk_17.png", 
  	"gfx/movefeet/survivor-walk_18.png", "gfx/movefeet/survivor-walk_19.png"
};

char *textureZombie[17] = {
	"gfx/tds_zombie/export/skeleton-idle_0.png", "gfx/tds_zombie/export/skeleton-idle_1.png",
	"gfx/tds_zombie/export/skeleton-idle_2.png", "gfx/tds_zombie/export/skeleton-idle_3.png",
	"gfx/tds_zombie/export/skeleton-idle_4.png", "gfx/tds_zombie/export/skeleton-idle_5.png",
	"gfx/tds_zombie/export/skeleton-idle_6.png", "gfx/tds_zombie/export/skeleton-idle_7.png",
	"gfx/tds_zombie/export/skeleton-idle_8.png", "gfx/tds_zombie/export/skeleton-idle_9.png",
	"gfx/tds_zombie/export/skeleton-idle_10.png", "gfx/tds_zombie/export/skeleton-idle_11.png",
	"gfx/tds_zombie/export/skeleton-idle_12.png", "gfx/tds_zombie/export/skeleton-idle_13.png",
	"gfx/tds_zombie/export/skeleton-idle_14.png", "gfx/tds_zombie/export/skeleton-idle_15.png",
	"gfx/tds_zombie/export/skeleton-idle_16.png"
};

int main(int argc, char *argv[]) {
	srand((uint8_t)time(0));
 	(void)argc;
 	(void)argv;

  	player blorp = {(SCREEN_WIDTH / 2), (SCREEN_HEIGHT / 2), 0.0f, 0.0f, UP, UP, UP, UP, 0.0, NULL, NULL, 0, 0, 0};
	zombie zombo = {0, 0, 0.0, NULL, 0};

	zombo.x = rand() % SCREEN_WIDTH;
	zombo.y = rand() % SCREEN_HEIGHT;

	muzzleflash flash = {0, 0, 0.0, NULL, 0};
	
  	// New: Mouse is a type representing a struct containing x and y coords of mouse pointer:
  	mouse mousepointer;
	
  	unsigned int window_flags = 0;
  	unsigned int renderer_flags = SDL_RENDERER_ACCELERATED;

  	// All Security Checks //
  	if (SDL_Init(SDL_INIT_VIDEO) < 0) exit(1);
  	window = SDL_CreateWindow("Blorp is going to F U UP!", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, window_flags);
  	if (window == NULL) exit(1);	
  	renderer = SDL_CreateRenderer(window, -1, renderer_flags);
  	if (renderer == NULL) exit(1);	

  	// Load All Textures //
  	IMG_Init(IMG_INIT_PNG);
  	mousepointer.txtr_reticle = load_texture("gfx/reticle.png");
  	blorp.txtr_body = load_texture("gfx/idlebody/survivor-idle_handgun_0.png"); 	// body
  	blorp.txtr_feet = load_texture("gfx/idlefeet/survivor-idle_0.png");		// feet

  	// No Visible Cursor For Us //
  	SDL_ShowCursor(0);

  	while (1) {
    		SDL_SetRenderDrawColor(renderer, 120, 144, 156, 255);
    		SDL_RenderClear(renderer);
		
    		// # Sensor Reading #
    		// Also takes the mouse movement into account:
    		process_input(&blorp, &mousepointer, &flash);

		if(flash.visible_state == 1) {
			draw_muzzleflash(&flash);
		}

    		show_bullet_route();

    		// # Applying Game Logic #
    		// Also takes the mouse movement into account:
    		update_player(&blorp, &mousepointer);

    		// # Actuator Output Buffering #
    		// Also takes texture rotation into account:
    		load_texture_blorp(&blorp);
		load_texture_zombie(&blorp, &zombo);

		blit_angled(zombo.txtr_zombie, zombo.x, zombo.y, zombo.angle);
		blit_angled(blorp.txtr_feet, blorp.x, blorp.y, blorp.angle);
    		blit_angled(blorp.txtr_body, blorp.x, blorp.y, blorp.angle);

    		// New: Redraw mouse pointer centered on the mouse coordinates:
    		blit(mousepointer.txtr_reticle, mousepointer.x, mousepointer.y, 1);
    		SDL_RenderPresent(renderer);
    		SDL_Delay(16);
  	}

  	return 0;
}

void load_texture_zombie(player *tha_playa, zombie *tha_zombo) {
	if (tha_zombo->location_idle_texture == 17) {
		tha_zombo->location_idle_texture = 0;
	}

	tha_zombo->txtr_zombie = load_texture(textureZombie[tha_zombo->location_idle_texture]);
	tha_zombo->angle = get_angle(tha_zombo->x, tha_zombo->y, tha_playa->x, tha_playa->y, tha_zombo->txtr_zombie);
	tha_zombo->location_idle_texture = tha_zombo->location_idle_texture + 1;
}

void init_muzzleflash(player *tha_playa, muzzleflash *tha_flash) {

	double angle 		= ((tha_playa->angle/180)*PI);
	double complement_x 	= (130*cos(angle)) - (56*sin(angle));
	double complement_y 	= (130*sin(angle)) + (56*cos(angle));

	tha_flash->x = (int)complement_x + tha_playa->x;
	tha_flash->y = (int)complement_y + tha_playa->y;
	tha_flash->angle = tha_playa->angle;
	tha_flash->txtr_flash = load_texture("gfx/muzzle_flash_01.png");
	tha_flash->visible_state = 1; //give it a 1 to make it visible
}

void draw_muzzleflash(muzzleflash *tha_flash) {


	SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_ADD);
	SDL_SetTextureBlendMode(tha_flash->txtr_flash, SDL_BLENDMODE_ADD);
	SDL_SetTextureColorMod(tha_flash->txtr_flash, 255, 255, 255);
	SDL_SetTextureAlphaMod(tha_flash->txtr_flash, 255);

	blit_angled(tha_flash->txtr_flash, tha_flash->x, tha_flash->y, (float)tha_flash->angle);
	tha_flash->visible_state = 0;

}

void load_texture_blorp(player *tha_playa) {
  	// Let's First Get The State Of The Player //
  	playerstate state = tha_playa->state;

  	if (state == 0) { 
    		if (tha_playa->location_idle_texture == 20) tha_playa->location_idle_texture = 0;
    
    		tha_playa->txtr_body = load_texture(texturesIdle[tha_playa->location_idle_texture]);
    		tha_playa->location_idle_texture = tha_playa->location_idle_texture + 1;
  	}
  	else if (state == 1) {
    		if (tha_playa->location_moving_texture == 20) tha_playa->location_moving_texture = 0;
      
    		tha_playa->txtr_body = load_texture(texturesBody[tha_playa->location_moving_texture]);
    		tha_playa->txtr_feet = load_texture(texturesFeet[tha_playa->location_moving_texture]);
    		tha_playa->location_moving_texture = tha_playa->location_moving_texture + 1;
  	}
}

// A New Function To Shoot That Bloody Pistol //
void make_bullet_casing(player *tha_playa) {
  	if (bullet_current_casing == BULLET_MAGAZINE) bullet_current_casing = 0;
  	bullet_current_casing++;

  	int bullet_casing 	= bullet_current_casing; 
  	double angle 		= ((tha_playa->angle/180)*PI); 

	double complement_x 	= (80*cos(angle)) - (56*sin(angle));
	double complement_y 	= (80*sin(angle)) + (56*cos(angle));

  	double x 		= tha_playa->x + (int)complement_x;
  	double y 		= tha_playa->y + (int)complement_y;
  	//int speed_x 		= (x - tha_mouse->x) / 50;	 
  	//int speed_y 		= (y - tha_mouse->y) / 50;	 
 	angle			= tha_playa->angle;	

  	// Make A bullet And Set All It's Values // 
  	bullet new_bullet = {bullet_casing, x, y, NULL, angle};
  	new_bullet.txtr_bullet = load_texture("gfx/bullet20x5.png");

  	// Insert The Bullet In The Bullet Array //
  	bullets[new_bullet.bullet_casing] = new_bullet;
}

void show_bullet_route() {
  	for (int a = 0; a < BULLET_MAGAZINE; a++) {
    		struct _bullet_ current_bullet = bullets[a];

    		current_bullet.x += cos((current_bullet.angle/180)*PI) * BULLET_ACCELERATION;
    		current_bullet.y += sin((current_bullet.angle/180)*PI) * BULLET_ACCELERATION;
    		bullets[current_bullet.bullet_casing] = current_bullet;

    		blit_angled(current_bullet.txtr_bullet, (int)current_bullet.x, (int)current_bullet.y, (float)current_bullet.angle);
  	}
}

// this has changed
void handle_key(SDL_KeyboardEvent *keyevent, keystate updown, player *tha_playa) {
  	if (keyevent->repeat == 0) {
    		if (keyevent->keysym.scancode == SDL_SCANCODE_W || keyevent->keysym.scancode == SDL_SCANCODE_S || 
			keyevent->keysym.scancode == SDL_SCANCODE_A || keyevent->keysym.scancode == SDL_SCANCODE_D ) {
	  
	 		 tha_playa->state = 1; // state 1 is WALKING //
    		}

    	if (keyevent->keysym.scancode == SDL_SCANCODE_W) tha_playa->up    = updown;      
    	if (keyevent->keysym.scancode == SDL_SCANCODE_S) tha_playa->down  = updown;		
    	if (keyevent->keysym.scancode == SDL_SCANCODE_A) tha_playa->left  = updown;
    	if (keyevent->keysym.scancode == SDL_SCANCODE_D) tha_playa->right = updown;		
  	}
}

// mouse click event
void process_input(player *tha_playa, mouse *tha_mouse, muzzleflash *tha_flash) {	
  	SDL_Event event;
	
  	while (SDL_PollEvent(&event))	{		
    		switch (event.type) {
      		case SDL_QUIT:	
        		proper_shutdown();
        		exit(0);
			break;

      		// Make A New Event That Works On A Button Press //
      		case SDL_MOUSEBUTTONDOWN:
			init_muzzleflash(tha_playa, tha_flash);
			make_bullet_casing(tha_playa);
			break;

      		case SDL_KEYDOWN:	
			if (event.key.keysym.scancode == SDL_SCANCODE_ESCAPE) {
	  			proper_shutdown();					
	  			exit(0);
			}		
			else {
	 			handle_key(&event.key, DOWN, tha_playa);
			}
			break;
      		case SDL_KEYUP:
			handle_key(&event.key, UP, tha_playa);
			break;
      		default:
			break;		
    		}
  	}

  	// NEW -- Read the mouse position here:
  	SDL_GetMouseState(&tha_mouse->x, &tha_mouse->y);
}

void update_player(player *tha_playa, mouse *tha_mouse) {
  	if (tha_playa->up) {
    		tha_playa->speed_y = (float)PLAYER_MAX_SPEED;
    		moveY = 1;

    		tha_playa->y -= (int)PLAYER_MAX_SPEED;
  	} 
  	if (tha_playa->down){		
    		tha_playa->speed_y = (float)PLAYER_MAX_SPEED;
    		moveY = 2;

    		tha_playa->y += (int)PLAYER_MAX_SPEED;	
  	}
  	if (tha_playa->left) {
    		tha_playa->speed_x = (float)PLAYER_MAX_SPEED;
    		moveX = 1;	

    		tha_playa->x -= (int)PLAYER_MAX_SPEED;
  	} 
  	if (tha_playa->right) {
    		tha_playa->speed_x = (float)PLAYER_MAX_SPEED;
    		moveX = 2;

    		tha_playa->x += (int)PLAYER_MAX_SPEED;	
  	}

  	// Make Sure It Slowly Walks Off (Y version) //
  	if (tha_playa->speed_y <= 0) {
    		moveY = 0;
  	} 
  	if (moveY != 0) {
    		// Step 1: Get The Current Speed Of Blorp 		//
    		float currentSpeed = (float)tha_playa->speed_y;

    		// Step 2: Remove A Slight Bit Off That Speed 	//
    		currentSpeed = (float)currentSpeed - PLAYER_DECELERATION;
    		tha_playa->speed_y = (float)currentSpeed - PLAYER_DECELERATION;

    		if (moveY == 1) {
      			// Step 3: Set It To y Of Blorp 			//
      			tha_playa->y = tha_playa->y - (int)currentSpeed;
    		} else if (moveY == 2) {
      			tha_playa->y = tha_playa->y + (int)currentSpeed;
    		}
  	}

  	// Make Sure It Slowly Walks Off (X version) //
  	if (tha_playa->speed_x <= 0) {
    		moveX = 0;
  	} 
  	if (moveX != 0) {
    		// Step 1: Get The Current Speed Of Blorp 		//
    		float currentSpeed = (float)tha_playa->speed_x;

    		// Step 2: Remove A Slight Bit Off That Speed 	//
    		currentSpeed = (float)currentSpeed - PLAYER_DECELERATION;
    		tha_playa->speed_x = (float)currentSpeed - PLAYER_DECELERATION;

    		if (moveX == 1) {
      			// Step 3: Set It To y Of Blorp 			//
      			tha_playa->x = tha_playa->x - (int)currentSpeed;
    		} else if (moveX == 2) {
      		tha_playa->x = tha_playa->x + (int)currentSpeed;
    		}
  	}

  	// set it back to idle
  	if (tha_playa->speed_x <= 0 && tha_playa->speed_y == 0) tha_playa->state = 0; // state 0 is for IDLE //

  	tha_playa->angle = get_angle(tha_playa->x, tha_playa->y, tha_mouse->x, tha_mouse->y, tha_playa->txtr_body);
}

void proper_shutdown(void) {
  	SDL_DestroyRenderer(renderer);
  	SDL_DestroyWindow(window);
  	SDL_Quit();
}

SDL_Texture *load_texture(char *filename) {
  	SDL_Texture *txtr;
  	txtr = IMG_LoadTexture(renderer, filename);
  	return txtr;
}

void blit(SDL_Texture *txtr, int x, int y, int center) {
  	SDL_Rect dest;
  	dest.x = x;
  	dest.y = y;

  	SDL_QueryTexture(txtr, NULL, NULL, &dest.w, &dest.h);

  	// If center != 0, render texture with its center on (x,y), NOT
  	// with its top-left corner...
  	if (center) {
    		dest.x -= dest.w / 2;
    		dest.y -= dest.h / 2;
  	}

  	SDL_RenderCopy(renderer, txtr, NULL, &dest);
}

void blit_angled(SDL_Texture *txtr, int x, int y, float angle) {
  	SDL_Rect dest;
  	dest.x = x;
  	dest.y = y;

  	SDL_QueryTexture(txtr, NULL, NULL, &dest.w, &dest.h);

  	// Textures that are rotated MUST ALWAYS be rendered with their
  	// center at (x, y) to have a symmetrical center of rotation:
  	dest.x -= (dest.w / 2);
  	dest.y -= (dest.h / 2);

  	// Look up what this function does. What do these rectangles
  	// mean? Why is the source rectangle NULL? What are acceptable
  	// values for the `angle' parameter?
  	SDL_RenderCopyEx(renderer, txtr, NULL, &dest, angle, NULL, SDL_FLIP_NONE);
}

float get_angle(int x1, int y1, int x2, int y2, SDL_Texture *txtr) {
  	// We Make Sure We Have Our Variables //
  	double pythagoras, sinusRule, arcTangus = 0;
  	int h = 0;

  	// We Want To Know Where Blorp Is //
  	SDL_QueryTexture(txtr, NULL, NULL, NULL, &h);

  	// Just To Keep Everything A Bit Organized //
  	double answerA, answerB;
  
  	// We Use Pyhtagaros To Calculate A Diagonal Distance Between Blorp And Mouse //
  	answerA = pow((x2 - x1), 2);
  	answerB = pow((y2 - y1), 2);
  	pythagoras = sqrt(answerA + answerB);

  	// After That We Use pythagoras And The Sinus Rule To Calulate Our Degree //
  	answerA = h / 3.75;
  	answerB = sin(90) / pythagoras;
  	sinusRule = asin(answerA * answerB);

  	// Now We Calculte It's Opposite //
  	answerA = y2 - y1;
  	answerB = x2 - x1;
  	arcTangus = atan2(answerA, answerB);

  	// We Calculate All Our Results And Transform It Into Degrees //
  	answerA = arcTangus - sinusRule;
  	answerB = 180 / PI;
  	
	return (float)(answerA * answerB);
}
